# Be sure to restart your server when you modify this file.

JournalApp::Application.config.session_store :cookie_store, key: '_JournalApp_session'
