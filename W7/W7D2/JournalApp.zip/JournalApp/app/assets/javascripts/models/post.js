JournalApp.Models.Post = Backbone.Model.extend({
});