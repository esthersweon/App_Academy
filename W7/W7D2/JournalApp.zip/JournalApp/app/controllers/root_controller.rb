class RootController < ApplicationController
	def root
		render :root
	end
end
