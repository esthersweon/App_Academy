require 'test_helper'

class RootHelperTest < ActionView::TestCase
end
